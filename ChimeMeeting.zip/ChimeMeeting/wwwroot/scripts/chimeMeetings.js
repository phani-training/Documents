﻿function testFunc(test) {
    alert(test);
}