﻿namespace ChimeMeeting.Data
{

    public class Attendee
    {
        public string ExternalUserId { get; set; } = string.Empty;
        public string AttendeeId { get; set; } = string.Empty;
        public string JoinToken { get; set; } = string.Empty;
    }

    public class MediaPlacement
    {
        public string AudioHostUrl { get; set; } =string.Empty;
        public string SignalingUrl { get; set; } = string.Empty;
    }
    public class Meeting
    {
        public string MeetingId { get; set; } = string.Empty;
        public string ExternalMeetingId { get; set; } = string.Empty;
        public MediaPlacement? MediaPlacement { get; set; } 
    }
public class MeetingDetail
    {
        public Attendee? Attendee { get; set; }

        public Meeting? Meeting { get; set; }
    }
}
