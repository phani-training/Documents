﻿using System.Net.Http;
using Microsoft.AspNetCore.Components;
using System.Threading.Tasks;

namespace ChimeMeeting.Data.Services
{
    public interface IArsMeeting
    {
        Task<MeetingDetail> CreateMeeting(string meetingId);

        Task<HttpResponseMessage> ShareMeeting();

        Task<HttpResponseMessage> JoinMeeting();
    }

    public class ArsMeeting : IArsMeeting
    {
        private readonly IHttpClientFactory httpClientFactory;
        private string UrlString = "https://pulud6u8je.execute-api.us-east-1.amazonaws.com/Prod/create?m=";
        public ArsMeeting(IHttpClientFactory factory) => httpClientFactory = factory;

        public async Task<MeetingDetail> CreateMeeting(string meetingId)
        {
            var httpClient = httpClientFactory.CreateClient();
            UrlString += meetingId;
            var response = await httpClient.GetFromJsonAsync<MeetingDetail>(UrlString);
            if(response != null)    
                return response;    
            return null;
        }

        public async Task<MeetingDetail> JoinMeeting(string mId, string joinee)
        {
            var url = $"https://pulud6u8je.execute-api.us-east-1.amazonaws.com/Prod/join?m={mId}&e=${joinee}";
            var httpClient = httpClientFactory.CreateClient();
            var response = await httpClient.GetFromJsonAsync<MeetingDetail>(url);
            if (response != null)
                return response;
            return null;
        }

        public Task<HttpResponseMessage> JoinMeeting()
        {
            throw new NotImplementedException();
        }

        public Task<HttpResponseMessage> ShareMeeting()
        {
            throw new NotImplementedException();
        }
    }
}
